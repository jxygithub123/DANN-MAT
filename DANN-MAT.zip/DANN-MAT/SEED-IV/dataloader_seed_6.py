import time
import scipy.io as iso
import numpy as np
import torch
from torchvision import datasets
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
batch_size = 30


class MyDataset(torch.utils.data.Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __getitem__(self, index):
        img, target = self.data[index], self.labels[index]
        return img, target

    def __len__(self):
        return len(self.data)






def get_data_label(input_file="2"):
    dataset_dir = "C:\\Users\\Riley\\dataset_seed_iv\\dataset_seediv\\"
    data_file = iso.loadmat(dataset_dir +input_file + ".mat")
#     data=[]
    #print(dataset_dir)
    data=np.squeeze(data_file['de_LDS1'])
    #print(data)
    for i in range(23):
        data_index=data_file['de_LDS'+str(i+2)]
#         data.append(data_index.reshape(-1,310))
#         print(data,data_index.reshape(-1,310))
        data=np.concatenate((data,data_index),axis=1)
    train_data=data.transpose(1,0,2)
    val0=np.mean(train_data[:,:,0])
    val1=np.mean(train_data[:,:,1])
    val2=np.mean(train_data[:,:,2])
    val3=np.mean(train_data[:,:,3])
    val4=np.mean(train_data[:,:,4])

    train_data[:,:,0]=train_data[:,:,0]-val0   ### 标准化的减去均值
    train_data[:,:,1]=train_data[:,:,1]-val1
    train_data[:,:,2]=train_data[:,:,2]-val2
    train_data[:,:,3]=train_data[:,:,3]-val3
    train_data[:,:,4]=train_data[:,:,4]-val4

    train_data[:,:,0]=2*train_data[:,:,0]/val0  ###  两倍内容除以均值
    train_data[:,:,1]=2*train_data[:,:,1]/val1
    train_data[:,:,2]=2*train_data[:,:,2]/val2
    train_data[:,:,3]=2*train_data[:,:,3]/val3
    train_data[:,:,4]=2*train_data[:,:,4]/val4
    
    

    
    #print("train_data.shape", train_data.shape)
    #print("test_data.shape", test_data.shape)
    data = train_data
    data = np.reshape(data, (data.shape[0], -1))
    # train_data = np.reshape(train_data, (train_data.shape[0], -1))
    # test_data = np.reshape(test_data, (test_data.shape[0], -1))
    #print("data.shape", data.shape)
    #print("train_data.shape", train_data.shape)
    #print("test_data.shape", test_data.shape)
    
    
    # labels=iso.loadmat(dataset_dir +'label' + ".mat")
    # labels = np.squeeze(labels['label'])
    labels_1=[]
    for i in range(24):
        data_index=data_file['de_LDS'+str(i+1)].reshape(-1,310)
        #print(data_index.shape)
        for j in range(len(data_index)):
            labels_1.append(i) 

#     data=np.squeeze(data)
    return data, np.array(labels_1)






def source_loader(source_dataset_name):
    source_data, source_label = get_data_label(source_dataset_name)
    dataloader = torch.utils.data.DataLoader(
    dataset=MyDataset(source_data, source_label),
    batch_size=batch_size,
    drop_last=True,
    shuffle=True,
    num_workers=1)
    return dataloader


def target_loader(target_dataset_name):
    target_data ,target_label = get_data_label(target_dataset_name)
    dataloader_target = torch.utils.data.DataLoader(
        dataset=MyDataset(target_data, target_label),
        batch_size=batch_size,
        drop_last=True,
        shuffle=True,
        num_workers=1)
    return dataloader_target




def sample_data(source_dataset_name):  ### 打乱数据

    data, label = get_data_label(source_dataset_name)
    n = len(data)
    X = torch.Tensor(n, 310)
    Y = torch.LongTensor(n)

    inds = torch.randperm(len(data))    ##
    for i, index in enumerate(inds):
        x, y = torch.tensor(data[index]), torch.tensor(label[index])
        X[i] = x
        Y[i] = y

    return X, Y

def create_target_samples(n, source_dataset_name):
    # dataset=datasets.SVHN('./data/SVHN', split='train', download=True,
    #                    transform=transforms.Compose([
    #                        transforms.Resize((28,28)),
    #                        transforms.Grayscale(),
    #                        transforms.ToTensor(),
    #                        transforms.Normalize([0.5], [0.5])
    #                    ]))

    data, label = get_data_label(source_dataset_name)
    # print(label.shape)  ##  3394
    # print('sum_label', sum(label))

    X, Y = [], []
    classes = 24 * [n]  ####  ten one [180, 180, 180]
    # print("classes", classes)
    i = 0
    while True:
        if len(X) == n * 24:  ## 当 n是10的时候
            break
        print(data.shape)
        print(label.shape)
        x, y = data[i], label[i]  ##  骚操作，留下每一种一个标签；一共15*n个数据，每个标签保存n个数据
        if classes[int(y)] > 0:
            X.append(x)
            Y.append(y)
            classes[int(y)] -= 1
        i += 1

    assert (len(X) == n * 24)
    aa = torch.from_numpy(np.array(X))
    bb = torch.from_numpy(np.array(Y))
    # print(bb.shape, aa.shape)
    # print("type(aa)", type(aa))
    # print("type(bb)", type(bb))
    #print("bb",  bb[10:20])   #bb有n个2,n个1,n个0组成(没有进行细分时)
    return aa, bb

"""
G1: a pair of pic comes from same domain ,same class
G3: a pair of pic comes from same domain, different classes

G2: a pair of pic comes from different domain,same class
G4: a pair of pic comes from different domain, different classes

G5: 都是目标域 相同类别
G6：都是目标域 不同类别
"""
    


def create_groups(X_s, Y_s ,X_s2, Y_s2, X_t, Y_t, seed=1):
    #change seed so every time wo get group data will different in source domain,but in target domain, data not change
    torch.manual_seed(1 + seed)
    torch.cuda.manual_seed(1 + seed)
    n= X_t.shape[0]   #10*shot #
    print("n", n)  ## 540 = 180 * 3
    #shuffle order
    classes = torch.unique(Y_t)  ##  其中 是否相等
    classes = classes[torch.randperm(len(classes))]

    class_num = classes.shape[0]
    print("classes", class_num)
    shot = n//class_num
    print("shot", shot)
    
    #创建左右脑源域
    X_s1=torch.zeros(X_s.shape[0],X_s.shape[1])
    for kk in range(X_s.shape[0]-1):
        
        X_s1[kk,10:15] = X_s[kk+1,10:15]
        X_s1[kk,20:25] = X_s[kk+1,20:25]
        X_s1[kk,50:70] = X_s[kk+1,50:70]
        X_s1[kk,95:115] = X_s[kk+1,95:115]
        X_s1[kk,140:160] = X_s[kk+1,140:160]
        X_s1[kk,185:205] = X_s[kk+1,185:205]
        X_s1[kk,230:250] = X_s[kk+1,230:250]
        X_s1[kk,270:285] = X_s[kk+1,270:285]
        X_s1[kk,300:310] = X_s[kk+1,300:310]
        
        X_s1[kk,0:10] = X_s[kk,0:10]
        X_s1[kk,15:20] = X_s[kk,15:20]
        X_s1[kk,25:50] = X_s[kk,25:50]
        X_s1[kk,70:95] = X_s[kk,70:95]
        X_s1[kk,115:140] = X_s[kk,115:140]
        X_s1[kk,160:185] = X_s[kk,160:185]
        X_s1[kk,205:230] = X_s[kk,205:230]
        X_s1[kk,250:270] = X_s[kk,250:270]
        X_s1[kk,285:300] = X_s[kk,285:300]        
        
    X_s1[X_s.shape[0]-1,:] = X_s[X_s.shape[0]-1,:]
      

                

    
    
    
    
    def s_idxs(c):
        idx = torch.nonzero(Y_s.eq(int(c)))
        return idx[torch.randperm(len(idx))][:shot*2].squeeze()

    def t_idxs(c):
        return torch.nonzero(Y_t.eq(int(c)))[:shot].squeeze()

    source_idxs = list(map(s_idxs, classes))
    target_idxs = list(map(t_idxs, classes))

    source_matrix = torch.stack(source_idxs)
    target_matrix = torch.stack(target_idxs)
    print(source_matrix.shape)    #源域3*540，方便相同标签两两对比
    print(target_matrix.shape)    #目标域3*270

    G1, G2, G3, G4, G5, G6 = [], [] , [] , [], [],[]
    G1_1, G2_1, G3_1, G4_1, G5_1, G6_1 = [], [] , [] , [], [],[]
    G1_2, G2_2, G3_2, G4_2, G5_2, G6_2 = [], [] , [] , [], [],[]
    
    Y1, Y2 , Y3 , Y4, Y5, Y6 = [], [] ,[] ,[], [], []
    Y1_1, Y2_1 , Y3_1 , Y4_1, Y5_1, Y6_1 = [], [] ,[] ,[], [], []
    Y1_2, Y2_2 , Y3_2 , Y4_2, Y5_2, Y6_2 = [], [] ,[] ,[], [], []
    """
    G1: 都是源域，相同类别(√)
    G2: 源域和目标域，相同类别
    G3: 都是源域不同类别(√)
    G4: 源域和目标域，不同类别
    
    G5: 都是目标域 相同类别
    G6：都是目标域 不同类别
    """
    for i in range(class_num):
        for j in range(shot):
            G1.append((X_s[source_matrix[i][j*2]], X_s[source_matrix[i][j*2+1]]))
            Y1.append((Y_s[source_matrix[i][j*2]], Y_s[source_matrix[i][j*2+1]]))
            G2.append((X_s[source_matrix[i][j]], X_t[target_matrix[i][j]]))
            Y2.append((Y_s[source_matrix[i][j]], Y_t[target_matrix[i][j]]))

            G3.append((X_s[source_matrix[i % 2][j]], X_s[source_matrix[(i+1) % 2][j]]))
            Y3.append((Y_s[source_matrix[i % 2][j]], Y_s[source_matrix[(i + 1) % 2][j]]))
            G4.append((X_s[source_matrix[i % 2][j]], X_t[target_matrix[(i+1) % 2][j]]))
            Y4.append((Y_s[source_matrix[i % 2][j]], Y_t[target_matrix[(i + 1) % 2][j]]))


    for i in range(class_num):
        for j in range(shot):
            G5.append((X_t[target_matrix[i][j]], X_t[target_matrix[i][int((j+1)%shot)]]))
            Y5.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[i][int((j+1)%shot)]]))
            if i == 0:
                G6.append((X_t[target_matrix[i][j]], X_t[target_matrix[(i+1) % 2][j]]))
                Y6.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[(i+1) % 2][j]]))
            else:
                G6.append((X_t[target_matrix[i][j]], X_t[target_matrix[(i + 1) % 2][int((j + 1) % shot)]]))
                Y6.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[(i + 1) % 2][int((j + 1) % shot)]]))
                
               
    for i in range(class_num):
        for j in range(shot):
            G1_1.append((X_s1[source_matrix[i][j*2]], X_s1[source_matrix[i][j*2+1]]))
            Y1_1.append((Y_s[source_matrix[i][j*2]], Y_s[source_matrix[i][j*2+1]]))
            G2_1.append((X_s1[source_matrix[i][j]], X_t[target_matrix[i][j]]))
            Y2_1.append((Y_s[source_matrix[i][j]], Y_t[target_matrix[i][j]]))

            G3_1.append((X_s1[source_matrix[i % 2][j]], X_s1[source_matrix[(i+1) % 2][j]]))
            Y3_1.append((Y_s[source_matrix[i % 2][j]], Y_s[source_matrix[(i + 1) % 2][j]]))
            G4_1.append((X_s1[source_matrix[i % 2][j]], X_t[target_matrix[(i+1) % 2][j]]))
            Y4_1.append((Y_s[source_matrix[i % 2][j]], Y_t[target_matrix[(i + 1) % 2][j]]))


    for i in range(class_num):
        for j in range(shot):
            G5_1.append((X_t[target_matrix[i][j]], X_t[target_matrix[i][int((j+1)%shot)]]))
            Y5_1.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[i][int((j+1)%shot)]]))
            if i == 0:
                G6_1.append((X_t[target_matrix[i][j]], X_t[target_matrix[(i+1) % 2][j]]))
                Y6_1.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[(i+1) % 2][j]]))
            else:
                G6_1.append((X_t[target_matrix[i][j]], X_t[target_matrix[(i + 1) % 2][int((j + 1) % shot)]]))
                Y6_1.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[(i + 1) % 2][int((j + 1) % shot)]]))
                
    for i in range(class_num):
        for j in range(shot):
            G1_2.append((X_s2[source_matrix[i][j*2]], X_s2[source_matrix[i][j*2+1]]))
            Y1_2.append((Y_s[source_matrix[i][j*2]], Y_s[source_matrix[i][j*2+1]]))
            G2_2.append((X_s2[source_matrix[i][j]], X_t[target_matrix[i][j]]))
            Y2_2.append((Y_s[source_matrix[i][j]], Y_t[target_matrix[i][j]]))

            G3_2.append((X_s2[source_matrix[i % 2][j]], X_s2[source_matrix[(i+1) % 2][j]]))
            Y3_2.append((Y_s[source_matrix[i % 2][j]], Y_s[source_matrix[(i + 1) % 2][j]]))
            G4_2.append((X_s2[source_matrix[i % 2][j]], X_t[target_matrix[(i+1) % 2][j]]))
            Y4_2.append((Y_s[source_matrix[i % 2][j]], Y_t[target_matrix[(i + 1) % 2][j]]))


    for i in range(class_num):
        for j in range(shot):
            G5_2.append((X_t[target_matrix[i][j]], X_t[target_matrix[i][int((j+1)%shot)]]))
            Y5_2.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[i][int((j+1)%shot)]]))
            if i == 0:
                G6_2.append((X_t[target_matrix[i][j]], X_t[target_matrix[(i+1) % 2][j]]))
                Y6_2.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[(i+1) % 2][j]]))
            else:
                G6_2.append((X_t[target_matrix[i][j]], X_t[target_matrix[(i + 1) % 2][int((j + 1) % shot)]]))
                Y6_2.append((Y_t[target_matrix[i][j]], Y_t[target_matrix[(i + 1) % 2][int((j + 1) % shot)]]))
    print(len(G1))
    print(len(G1[0]))
    print(len(G1[0][0]))
    groups=[G1, G2, G3, G4, G5, G6,G1_1, G2_1, G3_1, G4_1, G5_1, G6_1,G1_2, G2_2, G3_2, G4_2, G5_2, G6_2]    #G 810*2*310
    groups_y=[Y1, Y2, Y3, Y4, Y5, Y6,Y1_1, Y2_1, Y3_1, Y4_1, Y5_1, Y6_1,Y1_2, Y2_2, Y3_2, Y4_2, Y5_2, Y6_2]

    #make sure we sampled enough samples
    for g in groups:
        # print(len(g))
        assert(len(g) == n)
    # print("over")
    return groups, groups_y




def sample_groups(X_s,Y_s,X_s2, Y_s2,X_t,Y_t,seed=1):
    print("Sampling groups")
    return create_groups(X_s,Y_s,X_s2, Y_s2,X_t,Y_t,seed=seed)


